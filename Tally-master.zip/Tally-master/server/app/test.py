#!/usr/bin/env python
# -*- coding: utf-8 -*-
# @Date    : 2018-04-27 19:38:08
# @Author  : daiker (daikersec@gmail.com)
# @Link    : https://daikersec.com
# @Version : $Id$

from views import *
import datetime
if __name__ == '__main__':
    print inPlan(datetime.date(2018,06,01))
